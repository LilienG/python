from typing import Dict, List


class ResponseData:
    data_list: List[object]
    total: int

    def __init__(self, data_list=None, total: int = 0):
        if data_list is None:
            data_list = []
        self.data_list = data_list
        self.total = total


def fetch_data(input_file_path: str,
               page_size: int = 0, page: int = 1,
               sort_key: str = None, sort_order: str = 'asc',
               filter_dict: Dict = None) -> ResponseData:
    # read data from file
    # TODO: open the file and retrieve the content
    pass

    # process logic
    # TODO: achieve sort/paginate/filter/... logic according to the augments
    pass

    # return
    # TODO: modify codes below to return correct response
    response_data = ResponseData([], 0)
    return response_data
